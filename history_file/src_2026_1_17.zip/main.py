# main.py
import sys, os,pygame
from PySide6.QtWidgets import *
from main_ui import *  # 导入你生成的 UI 类
from PySide6.QtCore import *
from PySide6.QtMultimedia import *
from PySide6.QtGui import QMouseEvent, Qt
import random
import pylrc

import sys
from PySide6.QtWidgets import QApplication, QWidget, QLabel, QVBoxLayout
from PySide6.QtCore import Qt, QPoint
from PySide6.QtGui import QFont


class LyricWindow(QWidget):
    def __init__(self):
        super().__init__()

        # 设置窗口属性：无边框、置顶、工具窗口、背景透明
        self.setWindowFlags(
            Qt.WindowStaysOnTopHint |
            Qt.FramelessWindowHint |
            Qt.Tool
        )
        self.setAttribute(Qt.WA_TranslucentBackground)

        self.resize(400, 80)

        # 歌词标签
        self.lyric_label = QLabel("等待歌词...", self)
        self.lyric_label.setAlignment(Qt.AlignCenter)
        self.lyric_label.setStyleSheet("""
            color: white;
            background-color: rgba(0, 0, 0, 160);
            border-radius: 8px;
            padding: 8px;
            border: 1px solid rgba(255, 255, 255, 50);
        """)
        font = QFont("Microsoft YaHei", 12, QFont.Bold)
        self.lyric_label.setFont(font)

        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.lyric_label)
        self.setLayout(layout)

        # 用于拖拽的变量
        self._dragging = False
        self._offset = QPoint()

    def update_lyric(self, text):
        self.lyric_label.setText(text)

    # ===== 拖拽支持 =====
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._dragging = True
            self._offset = event.position().toPoint()

    def mouseMoveEvent(self, event):
        if self._dragging:
            # 移动窗口：当前鼠标全局位置 - 初始点击偏移
            self.move(event.globalPosition().toPoint() - self._offset)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._dragging = False

    def musiclrcchange(self, current_time, lyrics):
        sectime = current_time / 1000.0  # 转为秒（float）
        current_lyric = ""
        for line in lyrics:
            if line[0] <= sectime:
                current_lyric = line[1]
        self.update_lyric(current_lyric)

class MusicPlayerDialog(QDialog, Ui_Daybreak_music):
    def __init__(self, folderpath=""):
        super().__init__()
        self.setupUi(self)
        # 连接按钮点击信号到槽函数
        self.setMouseTracking(True)
        self.playmusic_control = 1
        self.rightfolderpath = []
        self.pushButton.clicked.connect(self.open_folder)
        self.listWidget.doubleClicked.connect(self.playmusic)
        self.listWidget.doubleClicked.connect(self.process_music)
        self.folderpath = folderpath

        self.play_control = 0

        self.pushButton_playmusic.clicked.connect(self.playmusic_button)
        self.timeprocess = 0
        self.horizontalSlider_processbar.setRange(0, 0)
        self.horizontalSlider_processbar.setValue(0)
        self.horizontalSlider_processbar.setEnabled(False)
        self.audio_output = QAudioOutput()

        self.index = 0

        self.player = QMediaPlayer()
        self.player.setAudioOutput(self.audio_output)

        self.timer = QTimer()
        self.timer.timeout.connect(self.process_music)
        self.timer.start(10)  # 10 ms = 0.01 秒

        self.slider_is_being_dragged = False

        self.horizontalSlider_processbar.sliderPressed.connect(self.on_slider_pressed)
        self.horizontalSlider_processbar.sliderReleased.connect(self.musicseek)

        self.pushButton_playmusic.setAutoDefault(False)
        self.pushButton.setAutoDefault(False)

        self.verticalSlider_setvoice.setRange(0, 100)
        self.verticalSlider_setvoice.setValue(50)
        self.audio_output.setVolume(0.5)  # 初始音量为50
        self.verticalSlider_setvoice.valueChanged.connect(self.change_volume)

        self.pushButton_beforesong.clicked.connect(self.beforesong)
        self.pushButton_nextsong.clicked.connect(self.nextsong)
        self.label_musicprocesstext.setText("00:00 / 00:00")


        self.checkBox_lrcshow.stateChanged.connect(self.lrc_show_hide)
        self.lyric_window = LyricWindow()

        self.lrc_handler = lrcchange()

        self.current_lyrics = []  # 用于缓存当前歌曲的歌词
        self.lrc_handler.lyricsLoaded.connect(self.on_lyrics_loaded)

    def on_lyrics_loaded(self, lyrics):
        self.current_lyrics = lyrics

    def change_volume(self):
        volume = self.verticalSlider_setvoice.value() / 100.0
        self.audio_output.setVolume(volume)

    def nextsong(self):
        if self.listWidget.currentRow() < self.listWidget.count() - 1:
            self.listWidget.setCurrentRow(self.listWidget.currentRow() + 1)
            url = QUrl.fromLocalFile(self.rightfolderpath[self.listWidget.currentRow()])
            self.player.setSource(url)
            self.player.play()
        else:

            url = QUrl.fromLocalFile(self.rightfolderpath[self.listWidget.currentRow()])
            self.listWidget.setCurrentRow(
                self.listWidget.currentRow() - self.listWidget.count()
            )
            self.player.setSource(url)
            self.player.play()

    def beforesong(self):
        if self.listWidget.currentRow() > 0:
            self.listWidget.setCurrentRow(self.listWidget.currentRow() - 1)
            url = QUrl.fromLocalFile(self.rightfolderpath[self.listWidget.currentRow()])
            self.player.setSource(url)
            self.player.play()
        else:
            url = QUrl.fromLocalFile(self.rightfolderpath[self.listWidget.currentRow()])
            self.listWidget.setCurrentRow(self.listWidget.count() - 1)
            self.player.setSource(url)
            self.player.play()

    def open_folder(self):
        # 打开文件夹选择对话框
        self.folderpath = QFileDialog.getExistingDirectory(
            self,
            "选择音乐文件夹",
            "",  # 起始目录，可设为 "C:/" 或上次路径
            QFileDialog.ShowDirsOnly,
        )
        if not self.folderpath:
            return  # 用户取消选择
        if self.folderpath:
            self.listWidget.clear()
            self.rightfolderpath = []
            print("选中的文件夹路径:", self.folderpath)
            for c in os.listdir(self.folderpath):
                if c.endswith(
                    (".mp3", ".wav", ".flac", ".ogg", "mgg", "mflac")
                ):  # 支持的音乐文件格式
                    print("找到音乐文件:", os.path.join(self.folderpath, c))
                    self.rightfolderpath.append(os.path.join(self.folderpath, c))
                else:
                    print("非音乐文件，跳过:", os.path.join(self.folderpath, c))
        self.listWidget.addItems(self.rightfolderpath)

    def playmusic_button(self):
        self.playmusic_control += 1
        if self.playmusic_control == 2:
            self.player.pause()
            self.playmusic_control = 0
        else:
            self.player.play()

    def playmusic(self):
        url = QUrl.fromLocalFile(self.rightfolderpath[self.listWidget.currentRow()])
        self.player.setSource(url)
        self.player.play()
        self.player.mediaStatusChanged.connect(self.on_media_status_changed)

    def process_music(self):
        self.horizontalSlider_processbar.setEnabled(True)
        duration = self.player.duration()  # 获取音乐总时长（毫秒）
        position = self.player.position()  # 获取当前播放位置（毫秒）
        if self.slider_is_being_dragged:
            return
        else:
            self.horizontalSlider_processbar.setRange(0, duration)
            self.horizontalSlider_processbar.setValue(position)


        totall_seconds = duration // 1000
        current_seconds = position // 1000

        totall_minutes = totall_seconds // 60
        totall_seconds = totall_seconds % 60
        current_minutes = current_seconds // 60
        current_seconds = current_seconds % 60
        self.label_musicprocesstext.setText(
            f"{current_minutes:02}:{current_seconds:02} / {totall_minutes:02}:{totall_seconds:02}"
        )
        self.lyric_window.musiclrcchange(position, self.current_lyrics)

    def on_slider_pressed(self):
        self.slider_is_being_dragged = True

    def musicseek(self):
        new_position = self.horizontalSlider_processbar.value()
        self.player.setPosition(new_position)
        self.slider_is_being_dragged = False



    def on_media_status_changed(self, status):
        self.index = self.comboBox_playmode.currentIndex()
        if status == QMediaPlayer.EndOfMedia:
            if self.index == 0:  # 顺序播放
                if self.listWidget.currentRow() < self.listWidget.count() - 1:
                    self.listWidget.setCurrentRow(self.listWidget.currentRow() + 1)
                    url = QUrl.fromLocalFile(
                        self.rightfolderpath[self.listWidget.currentRow()]
                    )
                    self.player.setSource(url)
                    self.player.play()
                else:

                    url = QUrl.fromLocalFile(
                        self.rightfolderpath[self.listWidget.currentRow()]
                    )
                    self.listWidget.setCurrentRow(
                        self.listWidget.currentRow() - self.listWidget.count()
                    )
                    self.player.setSource(url)
                    self.player.play()
            elif self.index == 1:  # 逆序播放
                if self.listWidget.currentRow() > 0:
                    self.listWidget.setCurrentRow(self.listWidget.currentRow() - 1)
                    url = QUrl.fromLocalFile(
                        self.rightfolderpath[self.listWidget.currentRow()]
                    )
                    self.player.setSource(url)
                    self.player.play()

                else:

                    url = QUrl.fromLocalFile(
                        self.rightfolderpath[self.listWidget.currentRow()]
                    )
                    self.listWidget.setCurrentRow(self.listWidget.count() - 1)
                    self.player.setSource(url)
                    self.player.play()

            elif self.index == 2:  # 循环播放
                url = QUrl.fromLocalFile(
                    self.rightfolderpath[self.listWidget.currentRow()]
                )
                self.player.setSource(url)
                self.player.play()

            elif self.index == 3:  # 随机播放
                random_index = random.randint(0, self.listWidget.count() - 1)
                self.listWidget.setCurrentRow(random_index)
                url = QUrl.fromLocalFile(
                    self.rightfolderpath[self.listWidget.currentRow()]
                )
                self.player.setSource(url)
                self.player.play()
        audio_path = self.rightfolderpath[self.listWidget.currentRow()]
        self.lrcpath = (
        audio_path
        .replace('.mp3', '.lrc')
        .replace('.wav', '.lrc')
        .replace('.flac', '.lrc')
        .replace('.ogg', '.lrc')
        .replace('.mgg', '.lrc')
        .replace('.mflac', '.lrc')
        )
        self.lrc_handler.set_path(self.lrcpath)
        if not self.lrc_handler.isRunning():  
            self.lrc_handler.start()
            #因为 一个 QThread 实例在其生命周期中只能 start() 一次。如果你在它还在运行时再次调用 start()，Qt 会抛出警告甚至引发未定义行为。
    def lrc_show_hide(self):
        if self.checkBox_lrcshow.isChecked():
            self.lyric_window.show()
        else:
            self.lyric_window.hide()
                # self.listWidget.setCurrentRow(self.listWidget.currentRow()+1)
                # url = QUrl.fromLocalFile(self.rightfolderpath[self.listWidget.currentRow()])
                # self.player.setSource(url)
                # self.player.play()



class lrcchange(QThread):
    lyricsLoaded = Signal(list)

    def __init__(self):
        super().__init__()
        self.lrcpath = ""

    def set_path(self, path):
        self.lrcpath = path

    def run(self):
        lyric_list = []
        content = ""
        try:
            # 先尝试 UTF-8
            with open(self.lrcpath, encoding='utf-8') as f:
                content = f.read()
                print("歌词文件以 UTF-8 编码读取成功")
        except UnicodeDecodeError:
            try:
                # 回退到 GBK / GB18030（支持更多中文字符）
                with open(self.lrcpath, encoding='gb18030') as f:
                    content = f.read()
                    print("歌词文件以 GB18030 编码读取成功")
            except Exception as e2:
                print(f"歌词文件编码无法识别（UTF-8/GB18030均失败）: {e2}")
                self.lyricsLoaded.emit([])
                return
        except Exception as e:
            print(f"读取歌词文件失败: {e}")
            self.lyricsLoaded.emit([])
            return

        try:
            subs = pylrc.parse(content)
            lyric_list = [(sub.time, sub.text) for sub in subs]
        except Exception as e:
            print(f"解析 LRC 失败: {e}")
            lyric_list = []

        self.lyricsLoaded.emit(lyric_list)  
        #在 PySide6（以及 Qt 框架）中，emit() 是信号（Signal） 的触发方法，用于从一个对象（通常是工作线程）向其他对象（通常是主线程中的 UI 组件）发送数据或通知。



if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MusicPlayerDialog()
    window.show()
    sys.exit(app.exec_())
