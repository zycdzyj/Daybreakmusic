# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 's.ui'
##
## Created by: Qt User Interface Compiler version 6.10.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QDialog,
    QLabel, QListWidget, QListWidgetItem, QPushButton,
    QSizePolicy, QSlider, QWidget)

class Ui_Daybreak_music(object):
    def setupUi(self, Daybreak_music):
        if not Daybreak_music.objectName():
            Daybreak_music.setObjectName(u"Daybreak_music")
        Daybreak_music.resize(1027, 658)
        self.label = QLabel(Daybreak_music)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(10, -10, 71, 71))
        self.pushButton = QPushButton(Daybreak_music)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setGeometry(QRect(0, 50, 151, 41))
        self.listWidget = QListWidget(Daybreak_music)
        self.listWidget.setObjectName(u"listWidget")
        self.listWidget.setGeometry(QRect(0, 180, 661, 341))
        self.pushButton_playmusic = QPushButton(Daybreak_music)
        self.pushButton_playmusic.setObjectName(u"pushButton_playmusic")
        self.pushButton_playmusic.setGeometry(QRect(580, 570, 101, 41))
        self.pushButton_playmusic.setCheckable(False)
        self.horizontalSlider_processbar = QSlider(Daybreak_music)
        self.horizontalSlider_processbar.setObjectName(u"horizontalSlider_processbar")
        self.horizontalSlider_processbar.setGeometry(QRect(10, 120, 581, 21))
        self.horizontalSlider_processbar.setOrientation(Qt.Horizontal)
        self.comboBox_playmode = QComboBox(Daybreak_music)
        self.comboBox_playmode.addItem("")
        self.comboBox_playmode.addItem("")
        self.comboBox_playmode.addItem("")
        self.comboBox_playmode.addItem("")
        self.comboBox_playmode.setObjectName(u"comboBox_playmode")
        self.comboBox_playmode.setGeometry(QRect(630, 120, 91, 31))
        self.pushButton_beforesong = QPushButton(Daybreak_music)
        self.pushButton_beforesong.setObjectName(u"pushButton_beforesong")
        self.pushButton_beforesong.setGeometry(QRect(510, 570, 71, 41))
        self.pushButton_nextsong = QPushButton(Daybreak_music)
        self.pushButton_nextsong.setObjectName(u"pushButton_nextsong")
        self.pushButton_nextsong.setGeometry(QRect(680, 570, 71, 41))
        self.label_musicprocesstext = QLabel(Daybreak_music)
        self.label_musicprocesstext.setObjectName(u"label_musicprocesstext")
        self.label_musicprocesstext.setGeometry(QRect(530, 60, 91, 21))
        self.checkBox_lrcshow = QCheckBox(Daybreak_music)
        self.checkBox_lrcshow.setObjectName(u"checkBox_lrcshow")
        self.checkBox_lrcshow.setGeometry(QRect(10, 150, 101, 21))
        self.verticalSlider_setvoice = QSlider(Daybreak_music)
        self.verticalSlider_setvoice.setObjectName(u"verticalSlider_setvoice")
        self.verticalSlider_setvoice.setGeometry(QRect(690, 190, 160, 22))
        self.verticalSlider_setvoice.setOrientation(Qt.Horizontal)

        self.retranslateUi(Daybreak_music)

        QMetaObject.connectSlotsByName(Daybreak_music)
    # setupUi

    def retranslateUi(self, Daybreak_music):
        Daybreak_music.setWindowTitle(QCoreApplication.translate("Daybreak_music", u"daybreak_music&\u7834\u6653\u97f3\u4e50", None))
        self.label.setText(QCoreApplication.translate("Daybreak_music", u"\u97f3\u4e50\u64ad\u653e\u5668", None))
        self.pushButton.setText(QCoreApplication.translate("Daybreak_music", u"\u6253\u5f00\u6587\u4ef6\u5939", None))
        self.pushButton_playmusic.setText(QCoreApplication.translate("Daybreak_music", u"\u64ad\u653e", None))
        self.comboBox_playmode.setItemText(0, QCoreApplication.translate("Daybreak_music", u"\u987a\u5e8f\u64ad\u653e", None))
        self.comboBox_playmode.setItemText(1, QCoreApplication.translate("Daybreak_music", u"\u9006\u5e8f\u64ad\u653e", None))
        self.comboBox_playmode.setItemText(2, QCoreApplication.translate("Daybreak_music", u"\u5faa\u73af\u64ad\u653e", None))
        self.comboBox_playmode.setItemText(3, QCoreApplication.translate("Daybreak_music", u"\u968f\u673a\u64ad\u653e", None))

        self.pushButton_beforesong.setText(QCoreApplication.translate("Daybreak_music", u"\u4e0a\u4e00\u9996", None))
        self.pushButton_nextsong.setText(QCoreApplication.translate("Daybreak_music", u"\u4e0b\u4e00\u9996", None))
        self.label_musicprocesstext.setText(QCoreApplication.translate("Daybreak_music", u"\u6b4c\u66f2\u65f6\u95f4\u663e\u793a", None))
        self.checkBox_lrcshow.setText(QCoreApplication.translate("Daybreak_music", u"\u663e\u793a\u6b4c\u8bcd", None))
    # retranslateUi

