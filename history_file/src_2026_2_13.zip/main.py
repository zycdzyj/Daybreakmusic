# main.py
import sys, os, pygame
from PySide6.QtWidgets import *
from main_ui import *  # 导入你生成的 UI 类
from PySide6.QtCore import *
from PySide6.QtMultimedia import *
from PySide6.QtGui import *
import random
import pylrc
import json
import urllib.parse
from random import randrange
import requests
from hashlib import md5
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
import time
import sys
from PySide6.QtWidgets import QApplication, QWidget, QLabel, QVBoxLayout
from PySide6.QtCore import Qt, QPoint
from PySide6.QtGui import QFont
from mutagen import File
from mutagen.id3 import ID3
from mutagen.id3 import APIC
from utils import api
from io import BytesIO
from PIL import Image
import base64
from pathlib import Path

class Api_163(QThread):
    search_finished = Signal(list)
    def __init__(self, keywords="",length=0):
        super().__init__()
        self.keywords = keywords
        self.length = length
        self.cookies = {
            "MUSIC_U": "0033A7C2605FEDE9A064B6B8C7F3E5B13708EF294DE512DABE74300EF86EE92A9173CA7669DB914F781C481ADA77E2C4049A0A7FC70BDE38EE8F613929C1C752822B49E50FEC5B939826B32A87AAC0B8EE624D1A00B76FDE1A1FF8121ACEC211B659A57A88314BBDCFB0514DE75AC0FEC9CB8299A88BEDFAE33108C9D9BBFAB15C84C82B7A65D1CEA4AE50F07B39B2B216FFE3B42BDBA570477EB6902B760A54CF912D08752CA18B54F97F0FE8F3DBE69C3BF7C8AEE5EC0115BB18880AAE6438DE2261975C69A43B06F465A0489676FAB59B54EE3E10C629B31980C23585AB95495B8EAD07808C70A7B954AA4944973CB5D4C9F5BEF30740736018AA4901E463E8045960C1EEF7874620D794BE3A65500F5AF8EEF225ADA3C2A3D9C9F5BB4235147F835E198F09F8EBEAD26E8D4A41C6347192A77F74E26BA38F5D4EBD90368A97CFF8FB35AA7DA64C0462FC88C335D09EA9A3CA5325618300A59FDD7A00C045A4E6155BE55525C86803A6F95E2CAEB1AE",
            "os": "pc",
            "appver": "8.9.75"
        }



    def run(self):
        print("搜索关键词:", self.keywords)
        print(api.search_music)
        self.songs = api.search_music(self.keywords, self.cookies, limit=50)
        if not self.songs:
            print("⚠️ 搜索无结果")
            self.search_finished.emit([])  # 或 emit 错误信息
            return
        
        if self.length >= len(self.songs):
            print(f"⚠️ 请求的索引 {self.length} 超出范围（共 {len(self.songs)} 首）")
            self.search_finished.emit([])
            return

        self.name=api.name_v1(self.songs[self.length]['id'])
        self.lyric=api.lyric_v1(self.songs[self.length]['id'], self.cookies)
        self.url=api.url_v1(self.songs[self.length]['id'],'standard', self.cookies)

        self.search_finished.emit(self.songs)
        return self.songs, self.name, self.lyric,self.url

class OnlineMusic_get(QThread):
    def __init__(self, id):
        super().__init__()
        self.id = id
        
        self.cookies = {
            "MUSIC_U": "0033A7C2605FEDE9A064B6B8C7F3E5B13708EF294DE512DABE74300EF86EE92A9173CA7669DB914F781C481ADA77E2C4049A0A7FC70BDE38EE8F613929C1C752822B49E50FEC5B939826B32A87AAC0B8EE624D1A00B76FDE1A1FF8121ACEC211B659A57A88314BBDCFB0514DE75AC0FEC9CB8299A88BEDFAE33108C9D9BBFAB15C84C82B7A65D1CEA4AE50F07B39B2B216FFE3B42BDBA570477EB6902B760A54CF912D08752CA18B54F97F0FE8F3DBE69C3BF7C8AEE5EC0115BB18880AAE6438DE2261975C69A43B06F465A0489676FAB59B54EE3E10C629B31980C23585AB95495B8EAD07808C70A7B954AA4944973CB5D4C9F5BEF30740736018AA4901E463E8045960C1EEF7874620D794BE3A65500F5AF8EEF225ADA3C2A3D9C9F5BB4235147F835E198F09F8EBEAD26E8D4A41C6347192A77F74E26BA38F5D4EBD90368A97CFF8FB35AA7DA64C0462FC88C335D09EA9A3CA5325618300A59FDD7A00C045A4E6155BE55525C86803A6F95E2CAEB1AE",
            "os": "pc",
            "appver": "8.9.75" 
        }

    def run(self):
        
        cache_path=Path(__file__).parent / "cache" / "online_music"
        os.makedirs(cache_path, exist_ok=True)

        self.lyric = api.lyric_v1(self.id, self.cookies)
        self.name = api.name_v1(self.id)

        filename = os.path.join(cache_path, (self.name['songs'][0]['name']+'_'+str(self.name['songs'][0]['id'])+'.mp3'))
        print("获取在线音乐信息成功:", self.name)
        self.url = api.url_v1(self.id, 'standard', self.cookies)
        print("获取在线音乐链接成功:", self.url)
        print("获取在线音乐歌词成功:", self.lyric)
        print(self.url['data'][0]['url'])
        response = requests.get(self.url['data'][0]['url'])
        response.raise_for_status()
        with open(filename, "wb") as f:
            f.write(response.content)

        # return self.lyric, self.name, self.url


# | 音质名称（显示名） | 内部 level 标识 | 码率（kbps） | 音频格式 | 采样率/位深 | 所需会员 | 说明 |
# |------------------|----------------|-------------|----------|--------------|----------|------|
# | 标准音质 | `standard` | 128 kbps | MP3 / AAC | 44.1kHz / 16bit | 免费用户 | 基础音质，适合弱网或省流量 |
# | 较高音质 | `higher` | 192 kbps | MP3 / AAC | 44.1kHz / 16bit | 免费用户 | 清晰度提升，日常推荐 |
# | 极高音质 | `exhigh` 或 `lossless`（旧版） | 320 kbps | MP3 / AAC | 44.1kHz / 16bit | 普通 VIP | 主流高音质，接近 CD 水平 |
# | 无损音质 | `lossless` | ≈900–1411 kbps | FLAC | 44.1kHz / 16bit | SVIP | 无损压缩，保留原始细节 |
# | Hi-Res 音质 | `hires` | 可达 9216 kbps | FLAC | 96kHz/24bit 或 192kHz/24bit | SVIP | 超高清，支持 Hi-Res Audio 认证设备 |
# | 超清母带（Master） | `jyeffect` 或 `master` | ≈17.8 MB/min（≈2370 kbps） | FLAC | 192kHz / 24bit | SVIP | 母带级重制，还原录音室细节 |
# | 沉浸式空间音频 | `spatial` / `dolby` | 动态码率 | AAC / Dolby Atmos | 多声道（如 5.1） | SVIP + 支持设备 | 环绕声体验，需耳机/音响支持 |


class LyricWindow(QWidget):
    def __init__(self):
        super().__init__()

        # 设置窗口属性：无边框、置顶、工具窗口、背景透明
        self.setWindowFlags(Qt.WindowStaysOnTopHint | Qt.FramelessWindowHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)

        self.resize(400, 80)


        # 歌词标签
        self.lyric_label = QLabel("等待歌词...", self)
        self.lyric_label.setAlignment(Qt.AlignCenter)
        self.lyric_label.setStyleSheet(
            """
            color: white;
            background-color: rgba(0, 0, 0, 160);
            border-radius: 8px;
            padding: 8px;
            border: 1px solid rgba(255, 255, 255, 50);
        """
        )
        font = QFont("Microsoft YaHei", 12, QFont.Bold)
        self.lyric_label.setFont(font)

        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.lyric_label)
        self.setLayout(layout)

        # 用于拖拽的变量
        self._dragging = False
        self._offset = QPoint()

    def update_lyric(self, text):
        self.lyric_label.setText(text)

    # ===== 拖拽支持 =====
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._dragging = True
            self._offset = event.position().toPoint()

    def mouseMoveEvent(self, event):
        if self._dragging:
            # 移动窗口：当前鼠标全局位置 - 初始点击偏移
            self.move(event.globalPosition().toPoint() - self._offset)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._dragging = False

    def musiclrcchange(self, current_time, lyrics):
        sectime = current_time / 1000.0  # 转为秒（float）
        current_lyric = ""
        for line in lyrics:
            if line[0] <= sectime:
                current_lyric = line[1]
        self.update_lyric(current_lyric)


class MusicPlayerDialog(QDialog, Ui_Daybreak_music):
    def __init__(self, folderpath=""):
        super().__init__()
        self.setupUi(self)
        self.setFixedSize(1070, 657)
        self.tabWidget.move(-2, -40)  # 初始位置，可以根据需要调整

        self.load_qss("C:\\Users\\ZHD\\Desktop\\编程py\\ui\\assets\\qss\\style1.qss")

        # 连接按钮点击信号到槽函数
        self.listWidget.setFocusPolicy(Qt.NoFocus)
        self.onlinesearch_tablewidget.setFocusPolicy(Qt.NoFocus)
        self.setMouseTracking(True)
        self.playmusic_control = 1
        self.rightfolderpath = []
        self.pushButton.clicked.connect(self.open_folder)
        self.listWidget.doubleClicked.connect(self.playmusic)
        self.listWidget.doubleClicked.connect(self.process_music)
        self.listWidget.doubleClicked.connect(self.clickcolorset)
        self.folderpath = folderpath

        self.play_control = 0

        self.pushButton_playmusic.clicked.connect(self.playmusic_button)
        self.timeprocess = 0
        self.horizontalSlider_processbar.setRange(0, 0)
        self.horizontalSlider_processbar.setValue(0)
        self.horizontalSlider_processbar.setEnabled(False)
        self.audio_output = QAudioOutput()

        self.index = 0

        self.player = QMediaPlayer()
        self.player.setAudioOutput(self.audio_output)

        self.timer = QTimer()
        self.timer.timeout.connect(self.process_music)
        self.timer.start(10)  # 10 ms = 0.01 秒

        self.slider_is_being_dragged = False

        self.horizontalSlider_processbar.sliderPressed.connect(self.on_slider_pressed)
        self.horizontalSlider_processbar.sliderReleased.connect(self.musicseek)

        self.pushButton_playmusic.setAutoDefault(False)
        self.pushButton_beforesong.setAutoDefault(False)
        self.pushButton_nextsong.setAutoDefault(False)
        self.pushButton.setAutoDefault(False)

        self.verticalSlider_setvoice.setRange(0, 100)
        self.verticalSlider_setvoice.setValue(50)
        self.audio_output.setVolume(0.5)  # 初始音量为50
        self.verticalSlider_setvoice.valueChanged.connect(self.change_volume)

        self.pushButton_beforesong.clicked.connect(self.beforesong)
        self.pushButton_nextsong.clicked.connect(self.nextsong)
        self.label_musicprocesstext.setText("00:00 / 00:00")

        self.checkBox_lrcshow.stateChanged.connect(self.lrc_show_hide)
        self.lyric_window = LyricWindow()

        self.lrc_handler = lrcchange()

        self.current_lyrics = []  # 用于缓存当前歌曲的歌词
        self.lrc_handler.lyricsLoaded.connect(self.on_lyrics_loaded)
        self.listWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.listWidget.setColumnWidth(0, 500)
        self.listWidget.setColumnWidth(1, 200)
        self.listWidget.setColumnWidth(2, 109)
        self.listWidget.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.listWidget.verticalHeader().setVisible(False)
        self.label_songname.setText("未选择")

        self.onlinesearch_tablewidget.setColumnWidth(0, 500)
        self.onlinesearch_tablewidget.setColumnWidth(1, 309)
        self.onlinesearch_tablewidget.setColumnWidth(2, 0)
        self.onlinesearch_tablewidget.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.onlinesearch_tablewidget.verticalHeader().setVisible(False)
        self.onlinesearch_tablewidget.clicked.connect(self.clickcolorset)
        self.onlinesearch_tablewidget.doubleClicked.connect(self.playmusic_online)
        # 设置第0行高度为40像素
        self.listWidget.setRowHeight(0, 40)

        # 设置所有行高为30
        for row in range(self.listWidget.rowCount()):
            self.listWidget.setRowHeight(row, 30)


# 更可靠的替代方案（视觉上接近）
        self.pushButton_beforesong.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_ArrowLeft))
        self.pushButton_nextsong.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_ArrowRight))
        self.pushButton_playmusic.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaPlay))

        self.pushButton_localmusicsearch.clicked.connect(lambda: self.tabWidget.setCurrentWidget(self.tab))
        self.pushButton_internetmusicsearch.clicked.connect(lambda: self.tabWidget.setCurrentWidget(self.tab_2))
        self.pushButton_localmusicsearch_2.clicked.connect(lambda: self.tabWidget.setCurrentWidget(self.tab))
        self.pushButton_internetmusicsearch_2.clicked.connect(lambda: self.tabWidget.setCurrentWidget(self.tab_2))
        self.lineEdit_163keywords.returnPressed.connect(self.search_music)
        self.onlinesearch_tablewidget.doubleClicked.connect(self.playmusic_online)

    def playmusic_online(self):
        length=self.onlinesearch_tablewidget.currentRow()
        if not self.songs:
            QMessageBox.warning(self, "错误", "请先搜索歌曲")
            return
        self.songs_url=OnlineMusic_get(self.songs[length]['id'])
        self.songs_url.start()
        self.songs_url.wait()

    def search_music(self):
        keywords = self.lineEdit_163keywords.text().strip()


        self.api_thread = Api_163(keywords)
        if hasattr(self, 'api_thread') and self.api_thread.isRunning():
            QMessageBox.information(self, "提示", "搜索正在进行，请稍后再试")
            return
        self.api_thread.search_finished.connect(self.on_search_finished)

        self.lineEdit_163keywords.setEnabled(False)
        self.api_thread.start()

    def on_search_finished(self, songs):
        self.songs=songs
        self.lineEdit_163keywords.setEnabled(True)
        table = self.onlinesearch_tablewidget
        table.setRowCount(0)  # 清空

        for i, song in enumerate(songs):
            table.insertRow(i)
            table.setItem(i, 0, QTableWidgetItem(song.get("name", "")))
            table.setItem(i, 1, QTableWidgetItem(song.get("artists", "")))
    def on_lyrics_loaded(self, lyrics):
        self.current_lyrics = lyrics
        # if not lyrics:
        #     self.current_lyrics = [[0.0,'未找到歌词或歌词文件损坏']]
        # print("歌词加载完成:", lyrics)
        if lyrics == []:
            self.current_lyrics = [[0.0, "未找到歌词或歌词文件损坏"]]

    def change_volume(self):
        volume = self.verticalSlider_setvoice.value() / 100.0
        self.audio_output.setVolume(volume)
    
    def load_qss(self, file_path):
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                qss = f.read()
                self.setStyleSheet(qss)
        except Exception as e:
            print(f"加载 QSS 文件失败: {e}")

    def _detect_image_format(self, data):
        try:
            img = Image.open(BytesIO(data))
            fmt = img.format.lower()
            return ".jpg" if fmt == "jpeg" else f".{fmt}"
            
        except Exception as e:
            print(f"无法识别图片格式, 使用默认 '.jpg': {e}")
            return ".jpg"

    def nextsong(self):
        if self.listWidget.currentRow() < self.listWidget.rowCount() - 1:
            self.listWidget.setCurrentCell((self.listWidget.currentRow() + 1), 0)
            url = QUrl.fromLocalFile(self.rightfolderpath[self.listWidget.currentRow()])
            self.player.setSource(url)
            self.player.play()
            self.play_control = 1
            self.label_songname.setText(
                self.listWidget.item(self.listWidget.currentRow(), 0).text()
            )
            self.song_picture()
        else:

            url = QUrl.fromLocalFile(self.rightfolderpath[self.listWidget.currentRow()])
            self.listWidget.setCurrentCell(
                (self.listWidget.currentRow() - self.listWidget.rowCount()), 0
            )
            self.player.setSource(url)
            self.player.play()
            self.play_control = 1
        self.label_songname.setText(
            self.listWidget.item(self.listWidget.currentRow(), 0).text()
        )
        self.song_picture()

    def song_picture(self):
        try:
            audio_path = self.rightfolderpath[self.listWidget.currentRow()]
        except IndexError:
            self.label_pictureload.clear()  # 清空封面
            return



        try:
            audio = File(audio_path)
        except Exception as e:
            print(f"无法读取音频文件: {e}")
            self.label_picture.clear()
            return

        if audio is None:
            self.label_picture.clear()
            return

        cover_data = None

        # ====== 提取封面数据（保持原逻辑）======
        if audio.__class__.__name__ == "MP3":
            if hasattr(audio, "tags") and audio.tags:
                apic_list = [
                    tag for tag in audio.tags.values() if isinstance(tag, APIC)
                ]
                if apic_list:
                    cover_data = apic_list[0].data

        elif audio.__class__.__name__ == "FLAC":
            if audio.pictures:
                cover_data = audio.pictures[0].data

        elif audio.__class__.__name__ in ("OggVorbis", "OggOpus"):
            if "metadata_block_picture" in audio:
                b64_pic = audio["metadata_block_picture"][0]
                try:
                    cover_data = base64.b64decode(b64_pic)
                except Exception as e:
                    print(f"Base64 解码失败: {e}")

        elif audio.__class__.__name__ == "MP4":
            if "covr" in audio:
                cover_data = bytes(audio["covr"][0])

        # ====== 直接从内存加载到 QPixmap ======
        if cover_data:
            pixmap = QPixmap()
            pixmap.loadFromData(cover_data)
            if not pixmap.isNull():
                # 缩放以适应 label（可选）
                scaled_pixmap = pixmap.scaled(
                    self.label_pictureload.size(),
                    Qt.KeepAspectRatio,
                    Qt.SmoothTransformation,
                )
                self.label_pictureload.setPixmap(scaled_pixmap)
                return

        # 若无封面，显示默认图或清空
        self.label_pictureload.clear()  # 或 setPixmap(QPixmap("default_cover.png"))

    def beforesong(self):
        if self.listWidget.currentRow() > 0:
            self.listWidget.setCurrentCell((self.listWidget.currentRow() - 1), 0)
            url = QUrl.fromLocalFile(self.rightfolderpath[self.listWidget.currentRow()])
            self.player.setSource(url)
            self.player.play()
            self.play_control = 1
        else:
            url = QUrl.fromLocalFile(self.rightfolderpath[self.listWidget.currentRow()])
            self.listWidget.setCurrentCell((self.listWidget.rowCount() - 1), 0)
            self.player.setSource(url)
            self.player.play()
            self.play_control = 1

        self.label_songname.setText(
            self.listWidget.item(self.listWidget.currentRow(), 0).text()
        )
        self.song_picture()

    def open_folder(self):
        # 打开文件夹选择对话框
        self.folderpath = QFileDialog.getExistingDirectory(
            self,
            "选择音乐文件夹",
            "",  # 起始目录，可设为 "C:/" 或上次路径
            QFileDialog.ShowDirsOnly,
        )
        if not self.folderpath:
            return  # 用户取消选择
        if self.folderpath:
            self.listWidget.clearContents()
            self.listWidget.setRowCount(0)  # 设置行数为 0
            self.rightfolderpath = []
            print("选中的文件夹路径:", self.folderpath)
            for c in os.listdir(self.folderpath):
                if c.endswith(
                    (".mp3", ".wav", ".flac", ".ogg", "mgg", "mflac")
                ):  # 支持的音乐文件格式
                    print("找到音乐文件:", os.path.join(self.folderpath, c))
                    self.rightfolderpath.append(os.path.join(self.folderpath, c))
                else:
                    print("非音乐文件，跳过:", os.path.join(self.folderpath, c))

            for path in self.rightfolderpath:
                row_position = self.listWidget.rowCount()
                self.listWidget.insertRow(row_position)

                filename = os.path.basename(path)
                self.listWidget.setItem(row_position, 0, QTableWidgetItem(filename))

                audio = File(path)
                if audio:
                    # 获取时长
                    duration = (
                        int(audio.info.length) if hasattr(audio.info, "length") else 0
                    )
                    minutes, seconds = divmod(duration, 60)
                    self.listWidget.setItem(
                        row_position, 1, QTableWidgetItem(f"{minutes:02}:{seconds:02}")
                    )

                    # 获取标签的辅助 lambda
                    get_tag = lambda tag: (
                        audio.tags.get(tag, [None])[0]
                        if audio.tags and tag in audio.tags
                        else None
                    )

                    # 修复：不要用不存在的 get_path_safe
                    artist = get_tag("artist") or get_tag("TPE1") or "未知作者"
                    title = (
                        get_tag("title")
                        or get_tag("TIT2")
                        or os.path.splitext(filename)[0]
                    )

                    self.listWidget.setItem(row_position, 1, QTableWidgetItem(artist))
                    self.listWidget.setItem(
                        row_position, 2, QTableWidgetItem(f"{minutes:02}:{seconds:02}")
                    )
                    # self.listWidget.setItem(row_position, 3, QTableWidgetItem(title))

                else:
                    print("无法读取音频文件")

    def playmusic_button(self):
        self.playmusic_control += 1
        if self.playmusic_control == 2:
            self.player.pause()
            self.pushButton_playmusic.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaPlay))
            self.playmusic_control = 0
        else:
            try:
                self.player.play()
                self.pushButton_playmusic.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaPause))
            except Exception as e:
                self.on_media_status_changed(QMediaPlayer.Error)
            self.playmusic_control = 1

    def clickcolorset(self):
        table = self.listWidget
        table.show()

        for col in range(self.listWidget.columnCount()):
            for row in range(self.listWidget.rowCount()):
                item = self.listWidget.item(row, col)
                if item:
                    item.setForeground(QColor("black"))
        item = self.listWidget.currentItem()
        if item:
            item.setForeground(QColor("red"))

    def playmusic(self):
        url = QUrl.fromLocalFile(self.rightfolderpath[self.listWidget.currentRow()])
        self.player.setSource(url)
        self.player.play()
        self.pushButton_playmusic.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaPause))
        self.player.mediaStatusChanged.connect(self.on_media_status_changed)

    def process_music(self):
        self.horizontalSlider_processbar.setEnabled(True)
        duration = self.player.duration()  # 获取音乐总时长（毫秒）
        position = self.player.position()  # 获取当前播放位置（毫秒）
        if self.slider_is_being_dragged:
            return
        else:
            self.horizontalSlider_processbar.setRange(0, duration)
            self.horizontalSlider_processbar.setValue(position)

        totall_seconds = duration // 1000
        current_seconds = position // 1000

        totall_minutes = totall_seconds // 60
        totall_seconds = totall_seconds % 60
        current_minutes = current_seconds // 60
        current_seconds = current_seconds % 60
        self.label_musicprocesstext.setText(
            f"{current_minutes:02}:{current_seconds:02} / {totall_minutes:02}:{totall_seconds:02}"
        )
        self.lyric_window.musiclrcchange(position, self.current_lyrics)

    def on_slider_pressed(self):
        self.slider_is_being_dragged = True

    def musicseek(self):
        new_position = self.horizontalSlider_processbar.value()
        self.player.setPosition(new_position)
        self.slider_is_being_dragged = False

    def on_media_status_changed(self, status):

        self.index = self.comboBox_playmode.currentIndex()

        if status == QMediaPlayer.EndOfMedia:
            if self.index == 0:  # 顺序播放
                if self.listWidget.currentRow() < self.listWidget.rowCount() - 1:
                    self.listWidget.selectRow(self.listWidget.currentRow() + 1)
                    url = QUrl.fromLocalFile(
                        self.rightfolderpath[self.listWidget.currentRow()]
                    )
                    self.player.setSource(url)
                    try:
                        self.player.play()
                    except Exception as e:
                        self.on_media_status_changed(QMediaPlayer.Error)
                        print("播放音乐时出错:", e)
                else:

                    url = QUrl.fromLocalFile(
                        self.rightfolderpath[self.listWidget.currentRow()]
                    )
                    self.listWidget.selectRow(
                        self.listWidget.currentRow() - self.listWidget.rowCount()
                    )
                    self.player.setSource(url)
                    self.player.play()
            elif self.index == 1:  # 逆序播放
                if self.listWidget.currentRow() > 0:
                    self.listWidget.selectRow(self.listWidget.currentRow() - 1)
                    url = QUrl.fromLocalFile(
                        self.rightfolderpath[self.listWidget.currentRow()]
                    )
                    self.player.setSource(url)
                    try:
                        self.player.play()
                    except:
                        self.on_media_status_changed(status)

                else:

                    url = QUrl.fromLocalFile(
                        self.rightfolderpath[self.listWidget.currentRow()]
                    )
                    self.listWidget.selectRow(self.listWidget.rowCount() - 1)
                    self.player.setSource(url)
                    try:
                        self.player.play()
                    except:
                        self.on_media_status_changed(QMediaPlayer.Error)

            elif self.index == 2:  # 循环播放
                url = QUrl.fromLocalFile(
                    self.rightfolderpath[self.listWidget.currentRow()]
                )
                self.player.setSource(url)
                try:
                    self.player.play()
                except:
                    self.on_media_status_changed(QMediaPlayer.Error)

            elif self.index == 3:  # 随机播放
                random_index = random.randint(0, self.listWidget.rowCount() - 1)
                self.listWidget.selectRow(random_index)
                url = QUrl.fromLocalFile(
                    self.rightfolderpath[self.listWidget.currentRow()]
                )
                self.player.setSource(url)
                try:
                    self.player.play()
                except:
                    self.on_media_status_changed(QMediaPlayer.Error)
        audio_path = self.rightfolderpath[self.listWidget.currentRow()]
        try:
            self.lrcpath = (
                audio_path.rsplit(".", 1)[0] + ".lrc"
            )  # 假设歌词文件与音频文件同名但扩展名为 .lrc
        except:
            print("获取歌词路径失败")

        self.lrc_handler.set_path(self.lrcpath)
        if not self.lrc_handler.isRunning():
            self.lrc_handler.start()
            # 因为 一个 QThread 实例在其生命周期中只能 start() 一次。如果你在它还在运行时再次调用 start()，Qt 会抛出警告甚至引发未定义行为。
        self.playmusic_control = 1
        self.label_songname.setText(
            self.listWidget.item(self.listWidget.currentRow(), 0).text()
        )
        self.song_picture()

    def lrc_show_hide(self):
        if self.checkBox_lrcshow.isChecked():
            self.lyric_window.show()
        else:
            self.lyric_window.hide()
            # self.listWidget.setCurrentRow(self.listWidget.currentRow()+1)
            # url = QUrl.fromLocalFile(self.rightfolderpath[self.listWidget.currentRow()])
            # self.player.setSource(url)
            # self.player.play()


class lrcchange(QThread):
    lyricsLoaded = Signal(list)

    def __init__(self):
        super().__init__()
        self.lrcpath = ""

    def set_path(self, path):
        self.lrcpath = path

    def run(self):
        lyric_list = []
        content = ""
        try:
            # 先尝试 UTF-8
            try:
                with open(self.lrcpath, encoding="utf-8") as f:
                    content = f.read()
                    print("歌词文件以 UTF-8 编码读取成功")
            except FileNotFoundError:
                print("歌词文件未找到")
                self.lyricsLoaded.emit([])
                return

        except UnicodeDecodeError:
            try:
                # 回退到 GBK / GB18030（支持更多中文字符）
                with open(self.lrcpath, encoding="gb18030") as f:
                    content = f.read()
                    print("歌词文件以 GB18030 编码读取成功")
            except Exception as e2:
                print(f"歌词文件编码无法识别（UTF-8/GB18030均失败）: {e2}")
                self.lyricsLoaded.emit([])
                return
        except Exception as e:
            print(f"读取歌词文件失败: {e}")
            self.lyricsLoaded.emit([])
            return

        try:
            subs = pylrc.parse(content)
            lyric_list = [(sub.time, sub.text) for sub in subs]
        except Exception as e:
            print(f"解析 LRC 失败: {e}")
            lyric_list = []

        self.lyricsLoaded.emit(lyric_list)
        # 在 PySide6（以及 Qt 框架）中，emit() 是信号（Signal） 的触发方法，用于从一个对象（通常是工作线程）向其他对象（通常是主线程中的 UI 组件）发送数据或通知。


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MusicPlayerDialog()
    window.show()
    sys.exit(app.exec())

