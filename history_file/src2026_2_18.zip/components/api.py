import json
import urllib.parse
from random import randrange
import requests
from hashlib import md5
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
def handle_api_error(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            print(f"调用API出错: {e}")
            import traceback
            traceback.print_exc()
            return None
    return wrapper
@handle_api_error
def search_music(keywords,cookies,limit=10):
    url= 'https://music.163.com/api/cloudsearch/pc'
    data = {'s': keywords, 'type': 1, 'limit': limit}
    headers = {
        'User-Agent': 'Mozilla/5.0',
        'Referer': 'https://music.163.com/'
    }
    response = requests.post(url, data=data, headers=headers, cookies=cookies)
    result = response.json()
    songs = []
    for item in result.get('result', {}).get('songs', []):
        song_info = {
            'id': item['id'],
            'name': item['name'],
            'artists': '/'.join(artist['name'] for artist in item['ar']),
            'album': item['al']['name'],
            'picUrl': item['al']['picUrl']
        }
        songs.append(song_info)
    return songs

