# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 's.ui'
##
## Created by: Qt User Interface Compiler version 6.10.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox,
    QDialog, QHeaderView, QLabel, QLineEdit,
    QPushButton, QSizePolicy, QSlider, QTabWidget,
    QTableWidget, QTableWidgetItem, QWidget)

class Ui_Daybreak_music(object):
    def setupUi(self, Daybreak_music):
        if not Daybreak_music.objectName():
            Daybreak_music.setObjectName(u"Daybreak_music")
        Daybreak_music.resize(1160, 1162)
        Daybreak_music.setStyleSheet(u"")
        self.tabWidget = QTabWidget(Daybreak_music)
        self.tabWidget.setObjectName(u"tabWidget")
        self.tabWidget.setGeometry(QRect(20, 130, 1081, 701))
        self.tab = QWidget()
        self.tab.setObjectName(u"tab")
        self.listWidget = QTableWidget(self.tab)
        if (self.listWidget.columnCount() < 3):
            self.listWidget.setColumnCount(3)
        __qtablewidgetitem = QTableWidgetItem()
        self.listWidget.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.listWidget.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.listWidget.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        self.listWidget.setObjectName(u"listWidget")
        self.listWidget.setGeometry(QRect(200, 50, 811, 361))
        self.listWidget.setStyleSheet(u"")
        self.listWidget.setSelectionMode(QAbstractItemView.SingleSelection)
        self.listWidget.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.horizontalSlider_processbar = QSlider(self.tab)
        self.horizontalSlider_processbar.setObjectName(u"horizontalSlider_processbar")
        self.horizontalSlider_processbar.setGeometry(QRect(120, 470, 581, 21))
        self.horizontalSlider_processbar.setOrientation(Qt.Horizontal)
        self.label_pictureload = QLabel(self.tab)
        self.label_pictureload.setObjectName(u"label_pictureload")
        self.label_pictureload.setGeometry(QRect(20, 460, 81, 81))
        self.pushButton = QPushButton(self.tab)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setGeometry(QRect(10, 560, 151, 41))
        self.pushButton_nextsong = QPushButton(self.tab)
        self.pushButton_nextsong.setObjectName(u"pushButton_nextsong")
        self.pushButton_nextsong.setGeometry(QRect(320, 550, 104, 41))
        self.pushButton_beforesong = QPushButton(self.tab)
        self.pushButton_beforesong.setObjectName(u"pushButton_beforesong")
        self.pushButton_beforesong.setGeometry(QRect(530, 550, 104, 41))
        self.pushButton_playmusic = QPushButton(self.tab)
        self.pushButton_playmusic.setObjectName(u"pushButton_playmusic")
        self.pushButton_playmusic.setGeometry(QRect(420, 550, 104, 41))
        self.pushButton_playmusic.setCheckable(False)
        self.comboBox_playmode = QComboBox(self.tab)
        self.comboBox_playmode.addItem("")
        self.comboBox_playmode.addItem("")
        self.comboBox_playmode.addItem("")
        self.comboBox_playmode.addItem("")
        self.comboBox_playmode.setObjectName(u"comboBox_playmode")
        self.comboBox_playmode.setGeometry(QRect(780, 530, 131, 44))
        self.comboBox_playmode.setStyleSheet(u"/* \u6574\u4f53\u7ec4\u5408\u6846 */\n"
"QComboBox {\n"
"    padding: 6px 32px 6px 12px; /* \u53f3\u4fa7\u7559\u51fa\u4e0b\u62c9\u7bad\u5934\u7a7a\u95f4 */\n"
"    border: 2px solid #3498db;\n"
"    border-radius: 8px;\n"
"    background-color: white;\n"
"    color: #333333;\n"
"    font-size: 14px;\n"
"    min-height: 28px;\n"
"}\n"
"\n"
"QComboBox:hover {\n"
"    border: 2px solid #2980b9;\n"
"}\n"
"\n"
"QComboBox::drop-down {\n"
"    subcontrol-origin: padding;\n"
"    subcontrol-position: top right;\n"
"    width: 24px;\n"
"    border: none;\n"
"    background: transparent;\n"
"}\n"
"\n"
"QComboBox::down-arrow {\n"
"    image: none; /* \u4e0d\u4f7f\u7528\u9ed8\u8ba4\u7bad\u5934 */\n"
"}\n"
"\n"
"QComboBox::down-arrow::before {\n"
"    content: \"\u25bc\";\n"
"    color: #3498db;\n"
"    font-size: 12px;\n"
"    position: absolute;\n"
"    right: 8px;\n"
"}\n"
"\n"
"/* \u4e0b\u62c9\u5217\u8868\u89c6\u56fe */\n"
"QComboBox QListView {\n"
"    border: 2px solid #3498db;\n"
"    border-radius: 8px;\n"
"    bac"
                        "kground-color: white;\n"
"    outline: 0;\n"
"    padding: 4px 0;\n"
"    color: #333;\n"
"}\n"
"\n"
"QComboBox QListView::item {\n"
"    height: 32px;\n"
"    padding-left: 12px;\n"
"    padding-right: 12px;\n"
"}\n"
"\n"
"QComboBox QListView::item:hover {\n"
"    background-color: #eaf5ff;\n"
"}\n"
"\n"
"QComboBox QListView::item:selected {\n"
"    background-color: #d6eaf8;\n"
"    color: #2c3e50;\n"
"}\n"
"\n"
"/* \u81ea\u5b9a\u4e49\u590d\u9009\u6846\u6837\u5f0f\uff08\u5173\u952e\uff1a\u7528 indicator \u6a21\u62df\uff09 */\n"
"QComboBox QListView::indicator {\n"
"    width: 16px;\n"
"    height: 16px;\n"
"    border: 2px solid #aaa;\n"
"    border-radius: 4px;\n"
"    background-color: white;\n"
"    margin-right: 8px;\n"
"}\n"
"\n"
"QComboBox QListView::indicator:hover {\n"
"    border: 2px solid #3498db;\n"
"}\n"
"\n"
"QComboBox QListView::indicator:checked {\n"
"    background-color: #3498db;\n"
"    border: 2px solid #3498db;\n"
"    image: url(); /* \u6e05\u9664\u9ed8\u8ba4\u52fe */\n"
"}\n"
"\n"
"/* "
                        "\u624b\u52a8\u7ed8\u5236\u201c\u2713\u201d\u7b26\u53f7\uff08Qt \u4e0d\u652f\u6301 content\uff0c\u4f46\u53ef\u901a\u8fc7\u900f\u660e\u56fe+\u80cc\u666f\u6a21\u62df\uff09 */\n"
"/* \u66f4\u53ef\u9760\u7684\u65b9\u5f0f\uff1a\u4f7f\u7528\u4e00\u5f20 16x16 \u7684\u767d\u8272\u5bf9\u52fe PNG \u56fe\u6807 */\n"
"/* \u5982\u679c\u4f60\u63a5\u53d7\u5c0f\u56fe\u6807\uff0c\u63a8\u8350\u4ee5\u4e0b\u65b9\u5f0f\uff1a */\n"
"\n"
"/*\n"
"QComboBox QListView::indicator:checked {\n"
"    image: url(:/icons/check_white_16.png);\n"
"    background-color: #3498db;\n"
"    border: 2px solid #3498db;\n"
"    border-radius: 4px;\n"
"}\n"
"*/")
        self.verticalSlider_setvoice = QSlider(self.tab)
        self.verticalSlider_setvoice.setObjectName(u"verticalSlider_setvoice")
        self.verticalSlider_setvoice.setGeometry(QRect(720, 470, 160, 22))
        self.verticalSlider_setvoice.setOrientation(Qt.Horizontal)
        self.checkBox_lrcshow = QCheckBox(self.tab)
        self.checkBox_lrcshow.setObjectName(u"checkBox_lrcshow")
        self.checkBox_lrcshow.setGeometry(QRect(660, 560, 101, 21))
        self.label_musicprocesstext = QLabel(self.tab)
        self.label_musicprocesstext.setObjectName(u"label_musicprocesstext")
        self.label_musicprocesstext.setGeometry(QRect(620, 430, 91, 21))
        self.label_songname = QLabel(self.tab)
        self.label_songname.setObjectName(u"label_songname")
        self.label_songname.setGeometry(QRect(30, 430, 181, 16))
        self.pushButton_localmusicsearch = QPushButton(self.tab)
        self.pushButton_localmusicsearch.setObjectName(u"pushButton_localmusicsearch")
        self.pushButton_localmusicsearch.setGeometry(QRect(10, 30, 101, 31))
        self.pushButton_internetmusicsearch = QPushButton(self.tab)
        self.pushButton_internetmusicsearch.setObjectName(u"pushButton_internetmusicsearch")
        self.pushButton_internetmusicsearch.setGeometry(QRect(10, 70, 101, 31))
        self.tabWidget.addTab(self.tab, "")
        self.tab_2 = QWidget()
        self.tab_2.setObjectName(u"tab_2")
        self.pushButton_internetmusicsearch_2 = QPushButton(self.tab_2)
        self.pushButton_internetmusicsearch_2.setObjectName(u"pushButton_internetmusicsearch_2")
        self.pushButton_internetmusicsearch_2.setGeometry(QRect(10, 70, 101, 31))
        self.pushButton_localmusicsearch_2 = QPushButton(self.tab_2)
        self.pushButton_localmusicsearch_2.setObjectName(u"pushButton_localmusicsearch_2")
        self.pushButton_localmusicsearch_2.setGeometry(QRect(10, 30, 101, 31))
        self.lineEdit_163keywords = QLineEdit(self.tab_2)
        self.lineEdit_163keywords.setObjectName(u"lineEdit_163keywords")
        self.lineEdit_163keywords.setGeometry(QRect(200, 40, 461, 21))
        self.pushButton_163search = QPushButton(self.tab_2)
        self.pushButton_163search.setObjectName(u"pushButton_163search")
        self.pushButton_163search.setGeometry(QRect(660, 40, 101, 23))
        self.onlinesearch_tablewidget = QTableWidget(self.tab_2)
        if (self.onlinesearch_tablewidget.columnCount() < 3):
            self.onlinesearch_tablewidget.setColumnCount(3)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.onlinesearch_tablewidget.setHorizontalHeaderItem(0, __qtablewidgetitem3)
        __qtablewidgetitem4 = QTableWidgetItem()
        self.onlinesearch_tablewidget.setHorizontalHeaderItem(1, __qtablewidgetitem4)
        __qtablewidgetitem5 = QTableWidgetItem()
        self.onlinesearch_tablewidget.setHorizontalHeaderItem(2, __qtablewidgetitem5)
        self.onlinesearch_tablewidget.setObjectName(u"onlinesearch_tablewidget")
        self.onlinesearch_tablewidget.setGeometry(QRect(130, 110, 811, 361))
        self.onlinesearch_tablewidget.setStyleSheet(u"")
        self.onlinesearch_tablewidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.onlinesearch_tablewidget.setSelectionMode(QAbstractItemView.SingleSelection)
        self.onlinesearch_tablewidget.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.pushButton_playmusic_2 = QPushButton(self.tab_2)
        self.pushButton_playmusic_2.setObjectName(u"pushButton_playmusic_2")
        self.pushButton_playmusic_2.setGeometry(QRect(470, 590, 104, 41))
        self.pushButton_playmusic_2.setCheckable(False)
        self.pushButton_beforesong_2 = QPushButton(self.tab_2)
        self.pushButton_beforesong_2.setObjectName(u"pushButton_beforesong_2")
        self.pushButton_beforesong_2.setGeometry(QRect(370, 590, 104, 41))
        self.pushButton_nextsong_2 = QPushButton(self.tab_2)
        self.pushButton_nextsong_2.setObjectName(u"pushButton_nextsong_2")
        self.pushButton_nextsong_2.setGeometry(QRect(570, 590, 104, 41))
        self.horizontalSlider_processbar_2 = QSlider(self.tab_2)
        self.horizontalSlider_processbar_2.setObjectName(u"horizontalSlider_processbar_2")
        self.horizontalSlider_processbar_2.setGeometry(QRect(260, 520, 581, 21))
        self.horizontalSlider_processbar_2.setOrientation(Qt.Horizontal)
        self.label_musicprocesstext_2 = QLabel(self.tab_2)
        self.label_musicprocesstext_2.setObjectName(u"label_musicprocesstext_2")
        self.label_musicprocesstext_2.setGeometry(QRect(770, 610, 91, 21))
        self.label_pictureload_2 = QLabel(self.tab_2)
        self.label_pictureload_2.setObjectName(u"label_pictureload_2")
        self.label_pictureload_2.setGeometry(QRect(40, 550, 81, 81))
        self.label_songname_2 = QLabel(self.tab_2)
        self.label_songname_2.setObjectName(u"label_songname_2")
        self.label_songname_2.setGeometry(QRect(30, 510, 181, 16))
        self.verticalSlider_setvoice_2 = QSlider(self.tab_2)
        self.verticalSlider_setvoice_2.setObjectName(u"verticalSlider_setvoice_2")
        self.verticalSlider_setvoice_2.setGeometry(QRect(180, 580, 160, 22))
        self.verticalSlider_setvoice_2.setOrientation(Qt.Horizontal)
        self.checkBox_lrcshow_2 = QCheckBox(self.tab_2)
        self.checkBox_lrcshow_2.setObjectName(u"checkBox_lrcshow_2")
        self.checkBox_lrcshow_2.setGeometry(QRect(770, 570, 101, 21))
        self.comboBox_playmode_2 = QComboBox(self.tab_2)
        self.comboBox_playmode_2.addItem("")
        self.comboBox_playmode_2.addItem("")
        self.comboBox_playmode_2.addItem("")
        self.comboBox_playmode_2.addItem("")
        self.comboBox_playmode_2.setObjectName(u"comboBox_playmode_2")
        self.comboBox_playmode_2.setGeometry(QRect(900, 570, 131, 44))
        self.comboBox_playmode_2.setStyleSheet(u"/* \u6574\u4f53\u7ec4\u5408\u6846 */\n"
"QComboBox {\n"
"    padding: 6px 32px 6px 12px; /* \u53f3\u4fa7\u7559\u51fa\u4e0b\u62c9\u7bad\u5934\u7a7a\u95f4 */\n"
"    border: 2px solid #3498db;\n"
"    border-radius: 8px;\n"
"    background-color: white;\n"
"    color: #333333;\n"
"    font-size: 14px;\n"
"    min-height: 28px;\n"
"}\n"
"\n"
"QComboBox:hover {\n"
"    border: 2px solid #2980b9;\n"
"}\n"
"\n"
"QComboBox::drop-down {\n"
"    subcontrol-origin: padding;\n"
"    subcontrol-position: top right;\n"
"    width: 24px;\n"
"    border: none;\n"
"    background: transparent;\n"
"}\n"
"\n"
"QComboBox::down-arrow {\n"
"    image: none; /* \u4e0d\u4f7f\u7528\u9ed8\u8ba4\u7bad\u5934 */\n"
"}\n"
"\n"
"QComboBox::down-arrow::before {\n"
"    content: \"\u25bc\";\n"
"    color: #3498db;\n"
"    font-size: 12px;\n"
"    position: absolute;\n"
"    right: 8px;\n"
"}\n"
"\n"
"/* \u4e0b\u62c9\u5217\u8868\u89c6\u56fe */\n"
"QComboBox QListView {\n"
"    border: 2px solid #3498db;\n"
"    border-radius: 8px;\n"
"    bac"
                        "kground-color: white;\n"
"    outline: 0;\n"
"    padding: 4px 0;\n"
"    color: #333;\n"
"}\n"
"\n"
"QComboBox QListView::item {\n"
"    height: 32px;\n"
"    padding-left: 12px;\n"
"    padding-right: 12px;\n"
"}\n"
"\n"
"QComboBox QListView::item:hover {\n"
"    background-color: #eaf5ff;\n"
"}\n"
"\n"
"QComboBox QListView::item:selected {\n"
"    background-color: #d6eaf8;\n"
"    color: #2c3e50;\n"
"}\n"
"\n"
"/* \u81ea\u5b9a\u4e49\u590d\u9009\u6846\u6837\u5f0f\uff08\u5173\u952e\uff1a\u7528 indicator \u6a21\u62df\uff09 */\n"
"QComboBox QListView::indicator {\n"
"    width: 16px;\n"
"    height: 16px;\n"
"    border: 2px solid #aaa;\n"
"    border-radius: 4px;\n"
"    background-color: white;\n"
"    margin-right: 8px;\n"
"}\n"
"\n"
"QComboBox QListView::indicator:hover {\n"
"    border: 2px solid #3498db;\n"
"}\n"
"\n"
"QComboBox QListView::indicator:checked {\n"
"    background-color: #3498db;\n"
"    border: 2px solid #3498db;\n"
"    image: url(); /* \u6e05\u9664\u9ed8\u8ba4\u52fe */\n"
"}\n"
"\n"
"/* "
                        "\u624b\u52a8\u7ed8\u5236\u201c\u2713\u201d\u7b26\u53f7\uff08Qt \u4e0d\u652f\u6301 content\uff0c\u4f46\u53ef\u901a\u8fc7\u900f\u660e\u56fe+\u80cc\u666f\u6a21\u62df\uff09 */\n"
"/* \u66f4\u53ef\u9760\u7684\u65b9\u5f0f\uff1a\u4f7f\u7528\u4e00\u5f20 16x16 \u7684\u767d\u8272\u5bf9\u52fe PNG \u56fe\u6807 */\n"
"/* \u5982\u679c\u4f60\u63a5\u53d7\u5c0f\u56fe\u6807\uff0c\u63a8\u8350\u4ee5\u4e0b\u65b9\u5f0f\uff1a */\n"
"\n"
"/*\n"
"QComboBox QListView::indicator:checked {\n"
"    image: url(:/icons/check_white_16.png);\n"
"    background-color: #3498db;\n"
"    border: 2px solid #3498db;\n"
"    border-radius: 4px;\n"
"}\n"
"*/")
        self.tabWidget.addTab(self.tab_2, "")

        self.retranslateUi(Daybreak_music)

        self.tabWidget.setCurrentIndex(1)


        QMetaObject.connectSlotsByName(Daybreak_music)
    # setupUi

    def retranslateUi(self, Daybreak_music):
        Daybreak_music.setWindowTitle(QCoreApplication.translate("Daybreak_music", u"daybreak_music&\u7834\u6653\u97f3\u4e50", None))
        ___qtablewidgetitem = self.listWidget.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("Daybreak_music", u"\u6b4c\u66f2\u540d", None));
        ___qtablewidgetitem1 = self.listWidget.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("Daybreak_music", u"\u4f5c\u8005", None));
        ___qtablewidgetitem2 = self.listWidget.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("Daybreak_music", u"\u64ad\u653e\u65f6\u957f", None));
        self.label_pictureload.setText(QCoreApplication.translate("Daybreak_music", u"\u56fe\u7247", None))
        self.pushButton.setText(QCoreApplication.translate("Daybreak_music", u"\u6253\u5f00\u6587\u4ef6\u5939", None))
        self.pushButton_nextsong.setText(QCoreApplication.translate("Daybreak_music", u"\u4e0b\u4e00\u9996", None))
        self.pushButton_beforesong.setText(QCoreApplication.translate("Daybreak_music", u"\u4e0a\u4e00\u9996", None))
        self.pushButton_playmusic.setText(QCoreApplication.translate("Daybreak_music", u"\u64ad\u653e", None))
        self.comboBox_playmode.setItemText(0, QCoreApplication.translate("Daybreak_music", u"\u987a\u5e8f\u64ad\u653e", None))
        self.comboBox_playmode.setItemText(1, QCoreApplication.translate("Daybreak_music", u"\u9006\u5e8f\u64ad\u653e", None))
        self.comboBox_playmode.setItemText(2, QCoreApplication.translate("Daybreak_music", u"\u5faa\u73af\u64ad\u653e", None))
        self.comboBox_playmode.setItemText(3, QCoreApplication.translate("Daybreak_music", u"\u968f\u673a\u64ad\u653e", None))

        self.checkBox_lrcshow.setText(QCoreApplication.translate("Daybreak_music", u"\u663e\u793a\u6b4c\u8bcd", None))
        self.label_musicprocesstext.setText(QCoreApplication.translate("Daybreak_music", u"\u6b4c\u66f2\u65f6\u95f4\u663e\u793a", None))
        self.label_songname.setText(QCoreApplication.translate("Daybreak_music", u"\u6b4c\u66f2\u540d", None))
        self.pushButton_localmusicsearch.setText(QCoreApplication.translate("Daybreak_music", u"\u672c\u5730\u97f3\u4e50", None))
        self.pushButton_internetmusicsearch.setText(QCoreApplication.translate("Daybreak_music", u"\u7f51\u7edc\u641c\u7d22", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab), QCoreApplication.translate("Daybreak_music", u"Tab 1", None))
        self.pushButton_internetmusicsearch_2.setText(QCoreApplication.translate("Daybreak_music", u"\u7f51\u7edc\u641c\u7d22", None))
        self.pushButton_localmusicsearch_2.setText(QCoreApplication.translate("Daybreak_music", u"\u672c\u5730\u97f3\u4e50", None))
        self.pushButton_163search.setText(QCoreApplication.translate("Daybreak_music", u"\u641c\u7d22\u7f51\u6613\u4e91\u97f3\u4e50", None))
        ___qtablewidgetitem3 = self.onlinesearch_tablewidget.horizontalHeaderItem(0)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("Daybreak_music", u"\u6b4c\u66f2\u540d", None));
        ___qtablewidgetitem4 = self.onlinesearch_tablewidget.horizontalHeaderItem(1)
        ___qtablewidgetitem4.setText(QCoreApplication.translate("Daybreak_music", u"\u4f5c\u8005", None));
        ___qtablewidgetitem5 = self.onlinesearch_tablewidget.horizontalHeaderItem(2)
        ___qtablewidgetitem5.setText(QCoreApplication.translate("Daybreak_music", u"\u64ad\u653e\u65f6\u957f", None));
        self.pushButton_playmusic_2.setText(QCoreApplication.translate("Daybreak_music", u"\u64ad\u653e", None))
        self.pushButton_beforesong_2.setText(QCoreApplication.translate("Daybreak_music", u"\u4e0a\u4e00\u9996", None))
        self.pushButton_nextsong_2.setText(QCoreApplication.translate("Daybreak_music", u"\u4e0b\u4e00\u9996", None))
        self.label_musicprocesstext_2.setText(QCoreApplication.translate("Daybreak_music", u"\u6b4c\u66f2\u65f6\u95f4\u663e\u793a", None))
        self.label_pictureload_2.setText(QCoreApplication.translate("Daybreak_music", u"\u56fe\u7247", None))
        self.label_songname_2.setText(QCoreApplication.translate("Daybreak_music", u"\u6b4c\u66f2\u540d", None))
        self.checkBox_lrcshow_2.setText(QCoreApplication.translate("Daybreak_music", u"\u663e\u793a\u6b4c\u8bcd", None))
        self.comboBox_playmode_2.setItemText(0, QCoreApplication.translate("Daybreak_music", u"\u987a\u5e8f\u64ad\u653e", None))
        self.comboBox_playmode_2.setItemText(1, QCoreApplication.translate("Daybreak_music", u"\u9006\u5e8f\u64ad\u653e", None))
        self.comboBox_playmode_2.setItemText(2, QCoreApplication.translate("Daybreak_music", u"\u5faa\u73af\u64ad\u653e", None))
        self.comboBox_playmode_2.setItemText(3, QCoreApplication.translate("Daybreak_music", u"\u968f\u673a\u64ad\u653e", None))

        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_2), QCoreApplication.translate("Daybreak_music", u"Tab 2", None))
    # retranslateUi

