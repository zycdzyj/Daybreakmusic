# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'chat_dialog.ui'
##
## Created by: Qt User Interface Compiler version 6.10.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QLabel, QLineEdit,
    QPushButton, QSizePolicy, QTextEdit, QWidget)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        if not Dialog.objectName():
            Dialog.setObjectName(u"Dialog")
        Dialog.resize(614, 342)
        Dialog.setStyleSheet(u"QWidget {\n"
"    color: white;\n"
"    background-color: rgba(0,0,0,60);\n"
"    border-radius: 8px;\n"
"    padding: 8px;\n"
"    border: 1px solid rgba(255, 255, 255, 50);\n"
"}\n"
"")
        self.lineEdit = QLineEdit(Dialog)
        self.lineEdit.setObjectName(u"lineEdit")
        self.lineEdit.setGeometry(QRect(30, 110, 491, 31))
        self.lineEdit.setStyleSheet(u"QLineEdit {\n"
"    /* \u80cc\u666f\u8272 - \u7070\u8272 */\n"
"    background-color: #f5f5f5;\n"
"    \n"
"    /* \u8fb9\u6846 */\n"
"    border: 1px solid #d0d0d0;\n"
"    border-radius: 6px;\n"
"    \n"
"    /* \u5185\u8fb9\u8ddd */\n"
"    padding: 8px 12px;\n"
"    \n"
"    /* \u6587\u5b57\u989c\u8272 */\n"
"    color: #333333;\n"
"    \n"
"    /* \u5b57\u4f53 */\n"
"    font-size: 14px;\n"
"    font-family: \"Microsoft YaHei\", \"Segoe UI\", sans-serif;\n"
"    \n"
"    /* \u9009\u4e2d\u80cc\u666f\u8272 */\n"
"    selection-background-color: #0078d7;\n"
"    selection-color: #ffffff;\n"
"}\n"
"\n"
"/* ---------- \u805a\u7126\u72b6\u6001 ---------- */\n"
"QLineEdit:focus {\n"
"    /* \u805a\u7126\u65f6\u8fb9\u6846\u989c\u8272\u52a0\u6df1 */\n"
"    border: 1px solid #0078d7;\n"
"    background-color: #ffffff;\n"
"    \n"
"    /* \u53ef\u9009\uff1a\u6dfb\u52a0\u9634\u5f71\u6548\u679c */\n"
"    /* \u6ce8\u610f\uff1aQt \u4e0d\u652f\u6301 box-shadow\uff0c\u53ef\u901a\u8fc7\u8fb9\u6846\u6a21\u62df */\n"
"}\n"
""
                        "\n"
"/* ---------- \u60ac\u505c\u72b6\u6001 ---------- */\n"
"QLineEdit:hover {\n"
"    border: 1px solid #a0a0a0;\n"
"    background-color: #fafafa;\n"
"}\n"
"")
        self.textEdit = QTextEdit(Dialog)
        self.textEdit.setObjectName(u"textEdit")
        self.textEdit.setGeometry(QRect(20, 10, 521, 51))
        self.textEdit.setStyleSheet(u"QTextEdit {\n"
"    background-color: transparent;\n"
"    border: 0px;\n"
"    border-radius: 0px;\n"
"    padding: 8px;\n"
"    color: #333333;\n"
"    selection-background-color: #0078d7;\n"
"    selection-color: #ffffff;\n"
"}\n"
"\n"
"/* \u83b7\u53d6\u7126\u70b9\u65f6\u7684\u6837\u5f0f */\n"
"QTextEdit:focus {\n"
"    border: 0px;\n"
"    outline: none;\n"
"    background-color: transparent;\n"
"}\n"
"\n"
"/* \u7981\u7528\u72b6\u6001 */\n"
"QTextEdit:disabled {\n"
"    background-color: transparent;\n"
"    color: #999999;\n"
"}\n"
"\n"
"/* \u53ea\u8bfb\u72b6\u6001 */\n"
"QTextEdit:read-only {\n"
"    background-color: transparent;\n"
"    color: #666666;\n"
"}\n"
"\n"
"/* \u9690\u85cf\u5782\u76f4\u6eda\u52a8\u6761 */\n"
"QTextEdit QScrollBar:vertical {\n"
"    width: 0px;\n"
"    background: transparent;\n"
"}\n"
"\n"
"/* \u9690\u85cf\u6c34\u5e73\u6eda\u52a8\u6761 */\n"
"QTextEdit QScrollBar:horizontal {\n"
"    height: 0px;\n"
"    background: transparent;\n"
"}\n"
"")
        self.label = QLabel(Dialog)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(30, 80, 131, 31))
        self.pushButton = QPushButton(Dialog)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setGeometry(QRect(440, 170, 104, 42))
        self.pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #e28c4a;      /* \u4e3b\u84dd\u8272 */\n"
"    border: none;                   /* \u65e0\u8fb9\u6846 */\n"
"    border-radius: 8px;             /* \u5706\u89d2\u534a\u5f84 */\n"
"    color: white;                   /* \u6587\u5b57\u767d\u8272 */\n"
"    padding: 6px 12px;              /* \u5185\u8fb9\u8ddd\uff0c\u8ba9\u6587\u5b57\u4e0d\u8d34\u8fb9 */\n"
"    font-size: 14px;\n"
"    min-width: 80px;\n"
"    min-height: 30px;\n"
"}\n"
"")
        self.pushButton_2 = QPushButton(Dialog)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setGeometry(QRect(440, 220, 104, 42))
        self.pushButton_2.setStyleSheet(u"QPushButton {\n"
"    background-color: #e28c4a;      /* \u4e3b\u84dd\u8272 */\n"
"    border: none;                   /* \u65e0\u8fb9\u6846 */\n"
"    border-radius: 8px;             /* \u5706\u89d2\u534a\u5f84 */\n"
"    color: white;                   /* \u6587\u5b57\u767d\u8272 */\n"
"    padding: 6px 12px;              /* \u5185\u8fb9\u8ddd\uff0c\u8ba9\u6587\u5b57\u4e0d\u8d34\u8fb9 */\n"
"    font-size: 14px;\n"
"    min-width: 80px;\n"
"    min-height: 30px;\n"
"}\n"
"")

        self.retranslateUi(Dialog)

        QMetaObject.connectSlotsByName(Dialog)
    # setupUi

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QCoreApplication.translate("Dialog", u"\u4fee\u6539cookie", None))
        self.textEdit.setHtml(QCoreApplication.translate("Dialog", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'SimSun'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\u901a\u8fc7cookie\u7684\u8bbe\u7f6e\u53ef\u4ee5\u8ba9\u4f60\u4f7f\u7528\u7f51\u6613\u4e91\u97f3\u4e50vip\u8d26\u53f7\u6765\u5728\u8fd9\u4e2a\u5ba2\u6237\u7aef\u4e0a\u542c\u97f3\u4e50,\u5982\u679c\u4f60\u8981\u83b7\u53d6cookie\u4f60\u53ef\u4ee5\u5728\u6d4f\u89c8\u5668\u7684\u5f00\u53d1\u8005\u6a21\u5f0f\u4e2d\u7684music_u\u627e\u5230\u5b83</p></body></html>", None))
        self.label.setText(QCoreApplication.translate("Dialog", u"\u8f93\u5165Music_U\u4ee5\u6fc0\u6d3b:", None))
        self.pushButton.setText(QCoreApplication.translate("Dialog", u"\u786e\u5b9a", None))
        self.pushButton_2.setText(QCoreApplication.translate("Dialog", u"\u53d6\u6d88", None))
    # retranslateUi

