# main.py
import sys, os, pygame
from PySide6.QtWidgets import *
from main_ui import *  # 导入你生成的 UI 类
from PySide6.QtCore import *
from PySide6.QtMultimedia import *
from PySide6.QtGui import QMouseEvent, Qt
import random


class MusicPlayerDialog(QDialog, Ui_Daybreak_music):
    def __init__(self, folderpath=""):
        super().__init__()
        self.setupUi(self)
        # 连接按钮点击信号到槽函数
        self.setMouseTracking(True)
        self.playmusic_control = 1
        self.rightfolderpath = []
        self.pushButton.clicked.connect(self.open_folder)
        self.listWidget.doubleClicked.connect(self.playmusic)
        self.listWidget.doubleClicked.connect(self.process_music)
        self.folderpath = folderpath

        self.play_control = 0

        self.pushButton_playmusic.clicked.connect(self.playmusic_button)
        self.timeprocess = 0
        self.horizontalSlider_processbar.setRange(0, 0)
        self.horizontalSlider_processbar.setValue(0)
        self.horizontalSlider_processbar.setEnabled(False)
        self.audio_output = QAudioOutput()

        self.index = 0

        self.player = QMediaPlayer()
        self.player.setAudioOutput(self.audio_output)

        self.timer = QTimer()
        self.timer.timeout.connect(self.process_music)
        self.timer.start(1000)  # 1000 ms = 1 秒

        self.slider_is_being_dragged = False

        self.horizontalSlider_processbar.sliderPressed.connect(self.on_slider_pressed)
        self.horizontalSlider_processbar.sliderReleased.connect(self.musicseek)

        self.pushButton_playmusic.setAutoDefault(False)
        self.pushButton.setAutoDefault(False)

        self.verticalSlider_setvoice.setRange(0, 100)
        self.verticalSlider_setvoice.setValue(50)
        self.audio_output.setVolume(0.5)  # 初始音量为50
        self.verticalSlider_setvoice.valueChanged.connect(self.change_volume)

        self.pushButton_beforesong.clicked.connect(self.beforesong)
        self.pushButton_nextsong.clicked.connect(self.nextsong)
        self.label_musicprocesstext.setText("00:00 / 00:00")

    def change_volume(self):
        volume = self.verticalSlider_setvoice.value() / 100.0
        self.audio_output.setVolume(volume)

    def nextsong(self):
        if self.listWidget.currentRow() < self.listWidget.count() - 1:
            self.listWidget.setCurrentRow(self.listWidget.currentRow() + 1)
            url = QUrl.fromLocalFile(self.rightfolderpath[self.listWidget.currentRow()])
            self.player.setSource(url)
            self.player.play()
        else:

            url = QUrl.fromLocalFile(self.rightfolderpath[self.listWidget.currentRow()])
            self.listWidget.setCurrentRow(
                self.listWidget.currentRow() - self.listWidget.count()
            )
            self.player.setSource(url)
            self.player.play()

    def beforesong(self):
        if self.listWidget.currentRow() > 0:
            self.listWidget.setCurrentRow(self.listWidget.currentRow() - 1)
            url = QUrl.fromLocalFile(self.rightfolderpath[self.listWidget.currentRow()])
            self.player.setSource(url)
            self.player.play()
        else:
            url = QUrl.fromLocalFile(self.rightfolderpath[self.listWidget.currentRow()])
            self.listWidget.setCurrentRow(self.listWidget.count() - 1)
            self.player.setSource(url)
            self.player.play()

    def open_folder(self):
        # 打开文件夹选择对话框
        self.folderpath = QFileDialog.getExistingDirectory(
            self,
            "选择音乐文件夹",
            "",  # 起始目录，可设为 "C:/" 或上次路径
            QFileDialog.ShowDirsOnly,
        )
        if not self.folderpath:
            return  # 用户取消选择
        if self.folderpath:
            self.listWidget.clear()
            self.rightfolderpath = []
            print("选中的文件夹路径:", self.folderpath)
            for c in os.listdir(self.folderpath):
                if c.endswith(
                    (".mp3", ".wav", ".flac", ".ogg", "mgg", "mflac")
                ):  # 支持的音乐文件格式
                    print("找到音乐文件:", os.path.join(self.folderpath, c))
                    self.rightfolderpath.append(os.path.join(self.folderpath, c))
                else:
                    print("非音乐文件，跳过:", os.path.join(self.folderpath, c))
        self.listWidget.addItems(self.rightfolderpath)

    def playmusic_button(self):
        self.playmusic_control += 1
        if self.playmusic_control == 2:
            self.player.pause()
            self.playmusic_control = 0
        else:
            self.player.play()

    def playmusic(self):
        url = QUrl.fromLocalFile(self.rightfolderpath[self.listWidget.currentRow()])
        self.player.setSource(url)
        self.player.play()
        self.player.mediaStatusChanged.connect(self.on_media_status_changed)

    def process_music(self):

        duration = self.player.duration()  # 获取音乐总时长（毫秒）
        position = self.player.position()  # 获取当前播放位置（毫秒）

        self.horizontalSlider_processbar.setRange(0, duration)
        self.horizontalSlider_processbar.setValue(position)
        self.horizontalSlider_processbar.setEnabled(True)

        totall_seconds = duration // 1000
        current_seconds = position // 1000

        totall_minutes = totall_seconds // 60
        totall_seconds = totall_seconds % 60
        current_minutes = current_seconds // 60
        current_seconds = current_seconds % 60
        self.label_musicprocesstext.setText(
            f"{current_minutes:02}:{current_seconds:02} / {totall_minutes:02}:{totall_seconds:02}"
        )
        

    def on_slider_pressed(self):
        self.slider_is_being_dragged = True

    def musicseek(self):
        new_position = self.horizontalSlider_processbar.value()
        self.player.setPosition(new_position)
        self.slider_is_being_dragged = False

    def on_media_status_changed(self, status):
        self.index = self.comboBox_playmode.currentIndex()
        if status == QMediaPlayer.EndOfMedia:
            if self.index == 0:  # 顺序播放
                if self.listWidget.currentRow() < self.listWidget.count() - 1:
                    self.listWidget.setCurrentRow(self.listWidget.currentRow() + 1)
                    url = QUrl.fromLocalFile(
                        self.rightfolderpath[self.listWidget.currentRow()]
                    )
                    self.player.setSource(url)
                    self.player.play()
                else:

                    url = QUrl.fromLocalFile(
                        self.rightfolderpath[self.listWidget.currentRow()]
                    )
                    self.listWidget.setCurrentRow(
                        self.listWidget.currentRow() - self.listWidget.count()
                    )
                    self.player.setSource(url)
                    self.player.play()
            elif self.index == 1:  # 逆序播放
                if self.listWidget.currentRow() > 0:
                    self.listWidget.setCurrentRow(self.listWidget.currentRow() - 1)
                    url = QUrl.fromLocalFile(
                        self.rightfolderpath[self.listWidget.currentRow()]
                    )
                    self.player.setSource(url)
                    self.player.play()

                else:

                    url = QUrl.fromLocalFile(
                        self.rightfolderpath[self.listWidget.currentRow()]
                    )
                    self.listWidget.setCurrentRow(self.listWidget.count() - 1)
                    self.player.setSource(url)
                    self.player.play()

            elif self.index == 2:  # 循环播放
                url = QUrl.fromLocalFile(
                    self.rightfolderpath[self.listWidget.currentRow()]
                )
                self.player.setSource(url)
                self.player.play()

            elif self.index == 3:  # 随机播放
                random_index = random.randint(0, self.listWidget.count() - 1)
                self.listWidget.setCurrentRow(random_index)
                url = QUrl.fromLocalFile(
                    self.rightfolderpath[self.listWidget.currentRow()]
                )
                self.player.setSource(url)
                self.player.play()

                # self.listWidget.setCurrentRow(self.listWidget.currentRow()+1)
                # url = QUrl.fromLocalFile(self.rightfolderpath[self.listWidget.currentRow()])
                # self.player.setSource(url)
                # self.player.play()




if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MusicPlayerDialog()
    window.show()
    sys.exit(app.exec_())
